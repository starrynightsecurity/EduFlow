export default function Layout({ children }) {
  return (
    <div>
      <nav className="nav">
        <div className="nav-inner">
          <span className="brand">EduFlow</span>
        </div>
      </nav>
      {children}
      <footer className="footer">
        <div>EduFlow — MVP starter · Deploy en Vercel</div>
      </footer>
    </div>
  )
}
