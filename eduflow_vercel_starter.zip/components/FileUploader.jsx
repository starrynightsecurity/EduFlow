import { useRef } from 'react'

export default function FileUploader({ onTextExtract }) {
  const fileRef = useRef()

  async function handleFile(e) {
    const file = e.target.files[0]
    if (!file) return
    const text = await fileToText(file)
    onTextExtract(text)
  }

  async function fileToText(file) {
    const textTypes = ['text/plain', 'application/json']
    if (textTypes.includes(file.type)) {
      return await file.text()
    }
    // For PDFs/images we recommend using OCR backend (TODO)
    return `--- Archivo '${file.name}' cargado. Para conversión automática a texto implementá OCR. ---`
  }

  return (
    <div>
      <label className="label">Subir archivo (texto / pdf / imagen)</label>
      <input type="file" ref={fileRef} onChange={handleFile} />
      <p className="muted">Si subís PDF o imagen, este starter muestra un mensaje. Recomendado: pegar texto mientras agregás OCR al backend.</p>
    </div>
  )
}
