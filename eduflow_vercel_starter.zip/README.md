# EduFlow — Vercel-ready Starter

**Quick start:** this starter is a clear, minimal Next.js app (UI in Spanish/English configurable)
with placeholder endpoints for all major IA features: presentations, flashcards, maps, documents.

## Files included
- `pages/index.js` — main UI
- `pages/api/processNotes.js` — single endpoint to run the core pipeline (summary, flashcards, slide)
- `pages/api/generateSlides.js` — slides generator (placeholder)
- `pages/api/generateFlashcards.js` — flashcard generator (placeholder)
- `pages/api/generateMap.js` — map conceptual generator (placeholder)
- `components/FileUploader.jsx`
- `components/Layout.jsx`
- `styles/globals.css`
- `.env.example`

## Deploy to Vercel
1. Create a new repo in GitHub and push this project.
2. Import the repo in Vercel.
3. Set environment variables in Vercel:
   - `OPENAI_API_KEY`
   - `NEXT_PUBLIC_APP_NAME=EduFlow`
   - `NEXT_PUBLIC_DEFAULT_LANG=es` (or 'en')
4. Deploy. The app will be available at https://<your-project>.vercel.app

## Notes
- The IA endpoints call OpenAI; make sure your API key is set in Vercel.
- OCR and heavy tasks are marked TODO — recommended to offload to workers for production.
