// API: processNotes
// Receives { text, output, lang } and returns summary, flashcards, slide, map
export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' })
  const { text, output = 'all', lang = 'es' } = req.body
  if (!text || !text.trim()) return res.status(400).json({ error: 'No text provided' })

  try {
    const apiKey = process.env.OPENAI_API_KEY
    if (!apiKey) return res.status(500).json({ error: 'OpenAI key not configured' })

    const system = lang === 'en'
      ? 'You are an educational assistant that extracts summaries, flashcards, slides and concept maps.'
      : 'Eres un asistente educativo que extrae resúmenes, flashcards, diapositivas y mapas conceptuales.'

    const prompt = `
    ${system}

    Analiza el siguiente texto de apuntes y devuelve un JSON con las claves:
    - summary: resumen breve (máx 200 palabras)
    - flashcards: [{q, a}]
    - slide: {title, bullets: []}
    - map: {nodes: [], edges: []}

    Texto:
    ${text}
    `

    const resp = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: [{ role: 'system', content: system }, { role: 'user', content: prompt }],
        temperature: 0.1,
        max_tokens: 900
      })
    })

    const j = await resp.json()
    const raw = j.choices?.[0]?.message?.content || ''

    // Try parse JSON
    let parsed = { summary: raw, flashcards: [], slide: raw, map: {} }
    try {
      // If model returns JSON, parse it
      const jsonStart = raw.indexOf('{')
      const jsonText = jsonStart >= 0 ? raw.slice(jsonStart) : raw
      const maybe = JSON.parse(jsonText)
      parsed.summary = maybe.summary || parsed.summary
      parsed.flashcards = maybe.flashcards || []
      parsed.slide = maybe.slide || parsed.slide
      parsed.map = maybe.map || {}
    } catch (e) {
      // Fallback: return raw as summary
      parsed.summary = raw
      parsed.slide = raw
    }

    return res.status(200).json(parsed)
  } catch (err) {
    console.error('processNotes error', err)
    return res.status(500).json({ error: 'Internal error', details: String(err) })
  }
}
