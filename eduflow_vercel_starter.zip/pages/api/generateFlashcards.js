// Placeholder endpoint for flashcards (can be used to store or transform flashcards)
export default async function handler(req, res) {
  return res.status(501).json({ error: 'Not implemented. Use /api/processNotes or implement DB storage.' })
}
