// Placeholder: generate PPTX serverless-friendly (use pptxgenjs on client or server worker)
export default async function handler(req, res) {
  return res.status(501).json({ error: 'Not implemented. Use pptxgenjs in a worker or client-side.' })
}
