// Placeholder endpoint for concept maps
export default async function handler(req, res) {
  return res.status(501).json({ error: 'Not implemented. The processNotes endpoint returns a map JSON.' })
}
