import Head from 'next/head'
import { useState } from 'react'
import FileUploader from '../components/FileUploader'
import Layout from '../components/Layout'
import '../styles/globals.css'

export default function Home() {
  const [text, setText] = useState('')
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState(null)
  const [lang, setLang] = useState(process.env.NEXT_PUBLIC_DEFAULT_LANG || 'es')

  async function handleGenerate(payload) {
    setLoading(true)
    setResult(null)
    try {
      const res = await fetch('/api/processNotes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...payload, lang })
      })
      const data = await res.json()
      setResult(data)
    } catch (e) {
      console.error(e)
      alert('Error procesando. Revisá la consola.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <Layout>
      <Head>
        <title>EduFlow — Starter</title>
      </Head>

      <main className="container">
        <header className="hero">
          <h1>EduFlow</h1>
          <p className="subtitle">Subí tus apuntes. Generá presentaciones, flashcards, mapas y más — automático.</p>
        </header>

        <section className="card">
          <FileUploader onTextExtract={(extracted) => setText(extracted)} />
          <div style={{marginTop:12}}>
            <label htmlFor="lang" style={{fontSize:14}}>Idioma de la interfaz:</label>
            <select id="lang" value={lang} onChange={(e)=>setLang(e.target.value)} style={{marginLeft:8}}>
              <option value="es">Español</option>
              <option value="en">English</option>
            </select>
          </div>

          <textarea className="textarea" value={text} onChange={(e)=>setText(e.target.value)} placeholder="Pegá o escribí tus apuntes aquí" />

          <div className="actions">
            <button className="btn" onClick={() => handleGenerate({ text, output: 'all' })} disabled={loading || !text}>
              {loading ? 'Procesando...' : 'Generar todo (resumen, flashcards, esquema)'}
            </button>
          </div>
        </section>

        <section className="card">
          <h2>Resultado</h2>
          {result ? (
            <div>
              <h3>Resumen</h3>
              <p>{result.summary}</p>

              <h3>Flashcards</h3>
              <ul>
                {result.flashcards && result.flashcards.map((f,i)=>(
                  <li key={i}><strong>Q:</strong> {f.q} <br /><strong>A:</strong> {f.a}</li>
                ))}
              </ul>

              <h3>Esquema (diapositiva)</h3>
              <pre style={{whiteSpace:'pre-wrap'}}>{result.slide}</pre>

              <h3>Mapa conceptual (JSON)</h3>
              <pre style={{whiteSpace:'pre-wrap'}}>{JSON.stringify(result.map, null, 2)}</pre>
            </div>
          ) : <p className="muted">Aún no generaste nada.</p>}
        </section>

      </main>
    </Layout>
  )
}
